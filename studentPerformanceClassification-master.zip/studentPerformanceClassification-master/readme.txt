-Install python3 from official website
-Install pip3 in python3
-Set enviromental and System variables
-pip3 install pandas
-pip3 install numpy
-pip3 install matplotlib
-pip3 install sklearn
-pip3 install scipy
-setup mysql server in your system
import student database in database 
update connection string in file 
mysql+mysqldb://USERNAME:"+'PASSWORD'+"@localhost/student

